module CompatResource
  VERSION = '12.5.26'
end
