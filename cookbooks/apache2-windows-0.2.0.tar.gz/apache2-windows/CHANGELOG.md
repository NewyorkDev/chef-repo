# CHANGELOG for apache2_windows

This file is used to list changes made in each version of apache2_windows.

## 0.2.0:

* First version of the rewritten cookbook.

## 0.1.1:

* Bumping for fun

## 0.1.0:

* Initial release of apache2_windows

- - -
Check the [Markdown Syntax Guide](http://daringfireball.net/projects/markdown/syntax) for help with Markdown.

The [Github Flavored Markdown page](http://github.github.com/github-flavored-markdown/) describes the differences between markdown on github and standard markdown.
